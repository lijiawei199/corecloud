package com.bananalab.corecloud.controller;

import com.bananalab.corecloud.api.HomeApiDelegate;
import com.bananalab.corecloud.api.model.Equiplist;
import com.bananalab.corecloud.api.model.Myindex;
import com.bananalab.corecloud.api.model.Search;
import com.bananalab.corecloud.api.model.Todaymsg;
import com.bananalab.corecloud.service.impl.StoreServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;


@Component
public class HomeController extends BaseDelegateImpl implements HomeApiDelegate {
    @Autowired
    StoreServiceImpl storeService = new StoreServiceImpl();


    @Override
    public ResponseEntity<Myindex> myindex() {
        return storeService.index();
    }

    @Override
    public ResponseEntity<Equiplist> remind(Integer type) {
        return null;
    }

    @Override
    public ResponseEntity<Search> search(String name) {
        return storeService.search(name);
    }


    @Override
    public ResponseEntity<Todaymsg> todaymsg() {
        return storeService.todaymsg();

    }
}
