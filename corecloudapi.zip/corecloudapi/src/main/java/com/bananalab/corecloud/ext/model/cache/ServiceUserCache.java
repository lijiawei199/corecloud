package com.bananalab.corecloud.ext.model.cache;

/**
 * @author: 李文龙
 * @create: 2019-09-19 11:04
 * @description: 服务人员缓存类
 **/
public class ServiceUserCache {
}

