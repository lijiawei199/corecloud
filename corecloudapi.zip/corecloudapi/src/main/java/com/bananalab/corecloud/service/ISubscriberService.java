package com.bananalab.corecloud.service;

import com.bananalab.corecloud.mybatis.model.Subscriber;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author 李佳伟
 * @since 2019-12-18
 */
public interface ISubscriberService extends IService<Subscriber> {

}
