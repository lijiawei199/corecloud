//package com.bananalab.corecloud.util;
//
//import org.apache.poi.ss.formula.functions.T;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//
//public class ResponseUtil {
//    public static ResponseEntity<T> respon(Object data, Object object) {
//        Class myclass = data.getClass();
//        try {
//            Method setCode = myclass.getMethod("setCode");
//            Method setData = myclass.getMethod("setData");
//            setCode.invoke(data, HttpStatus.OK);
//            setData.invoke(data, object);
//        } catch (NoSuchMethodException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (InvocationTargetException e) {
//            e.printStackTrace();
//        }
//        return ResponseEntity.ok((String) data);
//    }
//
//}
